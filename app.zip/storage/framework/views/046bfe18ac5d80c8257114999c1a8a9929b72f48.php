
<?php echo e($successed ?? ''); ?>

<?php echo e($csv_errors ?? ''); ?>

<form method='post' action='<?php echo e(route('esg.data.post')); ?>' enctype='multipart/form-data' >
<div class="row float-left">

<?php echo e(csrf_field()); ?>

<div class="col">

<input type="file" name="import_file" placeholder="File">
</div>
<div class="col">
<button type="submit" id="download_excell" class="download-btn">Submit</button>
</div>
<div class="col">
</div>

</div>
</form>
<?php /**PATH D:\script_uploader\script\resources\views\esg_data.blade.php ENDPATH**/ ?>